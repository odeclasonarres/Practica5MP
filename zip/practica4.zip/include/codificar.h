/**
@file 
@brief Funciones Codificar.
*/

bool ocultar (Imagen &, char mensaje[]);

bool revelar (Imagen &, char mensaje[],int MAXTAM);
